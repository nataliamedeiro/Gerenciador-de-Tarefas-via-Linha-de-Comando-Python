tarefa = {
    "nome": "Estudar Python",
    "descrição": "Revisar conceitos básicos de Python",
    "prioridade": "alta",
    "categoria": "estudos",
    "status": "pendente"
}

def adicionar_tarefa(tarefas, nome, descricao, prioridade, categoria):
    tarefa = {
        "nome": nome,
        "descrição": descricao,
        "prioridade": prioridade,
        "categoria": categoria,
        "status": "pendente"
    }
    tarefas.append(tarefa)
    print(f"Tarefa '{nome}' adicionada com sucesso!")

def listar_tarefas(tarefas):
    if not tarefas:
        print("Nenhuma tarefa cadastrada.")
        return
    for idx, tarefa in enumerate(tarefas):
        print(f"{idx + 1}. {tarefa['nome']} - {tarefa['descrição']} | Prioridade: {tarefa['prioridade']} | Categoria: {tarefa['categoria']} | Status: {tarefa['status']}")
def concluir_tarefa(tarefas, nome):
    for tarefa in tarefas:
        if tarefa['nome'] == nome:
            tarefa['status'] = 'concluída'
            print(f"Tarefa '{nome}' marcada como concluída!")
            return
    print(f"Tarefa '{nome}' não encontrada.")

def filtrar_tarefas(tarefas, filtro, valor):
    tarefas_filtradas = [tarefa for tarefa in tarefas if tarefa[filtro] == valor]
    if not tarefas_filtradas:
        print(f"Nenhuma tarefa encontrada com {filtro} '{valor}'.")
        return
    for tarefa in tarefas_filtradas:
        print(f"{tarefa['nome']} - {tarefa['descrição']} | Prioridade: {tarefa['prioridade']} | Categoria: {tarefa['categoria']} | Status: {tarefa['status']}")
def excluir_tarefa(tarefas, nome):
    for tarefa in tarefas:
        if tarefa['nome'] == nome:
            tarefas.remove(tarefa)
            print(f"Tarefa '{nome}' excluída com sucesso!")
            return
    print(f"Tarefa '{nome}' não encontrada.")
def exibir_menu():
    print("\nMenu de Comandos:")
    print("1. Adicionar Tarefa")
    print("2. Listar Tarefas")
    print("3. Filtrar Tarefas")
    print("4. Concluir Tarefa")
    print("5. Excluir Tarefa")
    print("6. Sair")
def main():
    tarefas = []  # Lista de tarefas
    while True:
        exibir_menu()
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            nome = input("Nome da tarefa: ")
            descricao = input("Descrição da tarefa: ")
            prioridade = input("Prioridade (baixa, média, alta): ")
            categoria = input("Categoria (trabalho, estudos, pessoal): ")
            adicionar_tarefa(tarefas, nome, descricao, prioridade, categoria)

        elif opcao == "2":
            listar_tarefas(tarefas)

        elif opcao == "3":
            filtro = input("Filtrar por (prioridade ou categoria): ")
            valor = input(f"Informe o valor de {filtro}: ")
            filtrar_tarefas(tarefas, filtro, valor)

        elif opcao == "4":
            nome = input("Nome da tarefa a concluir: ")
            concluir_tarefa(tarefas, nome)

        elif opcao == "5":
            nome = input("Nome da tarefa a excluir: ")
            excluir_tarefa(tarefas, nome)

        elif opcao == "6":
            print("Saindo do programa...")
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    main()
